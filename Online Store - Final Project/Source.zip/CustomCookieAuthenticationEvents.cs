﻿namespace Online_Store___Final_Project
{
    internal class CustomCookieAuthenticationEvents
    {
    }
}