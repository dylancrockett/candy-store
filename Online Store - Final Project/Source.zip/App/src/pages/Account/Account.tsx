import React from 'react';

const Account = () => {
    return (
        null
    );
};

export default Account;