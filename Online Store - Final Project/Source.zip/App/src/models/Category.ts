export default interface Category {
    categoryId: number,
    categoryName: string,
    categoryDescription: string,
    categoryImage: string,
}