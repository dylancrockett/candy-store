export default interface OrderItem {
    orderId: number,
    itemId: number,
    itemCount: number,
}