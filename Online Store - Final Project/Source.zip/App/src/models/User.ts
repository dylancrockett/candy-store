export default interface User {
    userId: number,
    userName: string,
    userEmail: string
}