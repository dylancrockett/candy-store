export default interface State {
    stateId: number,
    stateName: string,
    stateCode: string
}