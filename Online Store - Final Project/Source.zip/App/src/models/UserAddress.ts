export default interface UserAddress {
    userAddressId: number,
    userId: number,
    address: string,
    city: string,
    stateId: number
}