export default interface Order {
    orderId: number,
    orderDate: string,
    userId: number,
    userAddressId: number
}