export default interface Item {
    itemId: number,
    itemName: string,
    itemDescription: string,
    itemCost: number,
    itemImage: string
    categoryId: number
}